#include <glimac/SDLWindowManager.hpp>
#include <glimac/Program.hpp>
#include <glimac/FilePath.hpp>
#include <glimac/glm.hpp>
#include <GL/glew.h>
#include <iostream>

using namespace glimac;

class Vertex2DColor
{
    public:
    Vertex2DColor();
    Vertex2DColor(glm::vec2 position, glm::vec3 color);
    
    glm::vec2 position;
    glm::vec3 color;

};

Vertex2DColor::Vertex2DColor(){};

Vertex2DColor::Vertex2DColor(glm::vec2 position, glm::vec3 color):position(position),color(color){
};




int main(int argc, char** argv) {
    // Initialize SDL and open a window
    SDLWindowManager windowManager(800, 600, "GLImac");

    // Initialize glew for OpenGL3+ support
    GLenum glewInitError = glewInit();
    if(GLEW_OK != glewInitError) {
        std::cerr << glewGetErrorString(glewInitError) << std::endl;
        return EXIT_FAILURE;
    }

    std::cout << "OpenGL Version : " << glGetString(GL_VERSION) << std::endl;
    std::cout << "GLEW Version : " << glewGetString(GLEW_VERSION) << std::endl;

	FilePath applicationPath(argv[0]);
	//Program program = loadProgram(applicationPath.dirPath() + "shaders/triangle.vs.glsl",
	//	                      applicationPath.dirPath() + "shaders/triangle.fs.glsl");
    Program program = loadProgram(applicationPath.dirPath() + "shaders/text2D.vs.glsl",
		                      applicationPath.dirPath() + "shaders/text2D.fs.glsl");
	program.use();

    /*********************************
     * HERE SHOULD COME THE INITIALIZATION CODE
     *********************************/
	// creation du VBO
	GLuint vbo;

	glGenBuffers(1 ,&vbo );

	// binding du buffer (le lier a une cible) AVEC GL_ARRAY_BUFFER, chemin d'acces ves le buffer
	glBindBuffer(GL_ARRAY_BUFFER, vbo);



    /////////////////////////////////////////////////////
    //Creation d'un tableau de float contenant les sommets du triangle (vertex)
    // vertices ={x1,y1,x2,y2 . . . . }
    /////////////////////////////////////////////////////
	/*GLfloat vertices[] = {-0.5f, -0.5f,1.f,0.f,0.f,
	                     0.5f,-0.5f,0.f,1.f,0.f,
	                     0.0f,0.5f,0.f,0.f,0.f};*/
	Vertex2DColor vertices[] = {
	    Vertex2DColor(glm::vec2(-0.5f,-0.5f),glm::vec3(1,0,0)),
	    Vertex2DColor(glm::vec2(0.5,-0.5),glm::vec3(0,1,0)),
	    Vertex2DColor(glm::vec2(-0.5 ,0.5),glm::vec3(0,0,1)),
	    Vertex2DColor(glm::vec2(-0.5,0.5),glm::vec3(0,0,1)),
	    Vertex2DColor(glm::vec2(0.5,-0.5),glm::vec3(0,1,0)),
	    Vertex2DColor(glm::vec2(0.5,0.5),glm::vec3(1,0,0))
	};
	                     
	                     
	                     
	//on envoi les datas, vers (cible, nbr de data, quest ce quon envoi, quel est lusage du buffer)
	glBufferData(GL_ARRAY_BUFFER,6*sizeof(Vertex2DColor),vertices,GL_STATIC_DRAW);
    // on debind 
	glBindBuffer(GL_ARRAY_BUFFER, 0);


    ///les données de vertex sont à présent stockés sur le GPU

	// creation du vao (le VAO indique le type (qui se nomme attribut) des donnée (sommet, coleur etc))	
	GLuint vao;	
	glGenVertexArrays(1, &vao);
	
	//binding	
	glBindVertexArray(vao);	

    //3 = position||||||8 =color
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	
	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	
	// index, nbr de composantes de l'attribut, type, nomalized,stride(nbr d'octet jusquau mm attribut du sommet suivant), pointer
	glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(Vertex2DColor),(void*)offsetof(Vertex2DColor,position));
	//glVertexAttribPointer(8,3,GL_FLOAT,GL_FALSE,sizeof(Vertex2DColor),(void*)(2*sizeof(GLfloat)));
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(Vertex2DColor),(void*)offsetof(Vertex2DColor,color));
    
	glBindVertexArray(0);
    /////////////////////////////////////////////////////////////////////////////////////////////////////



    // Application loop:
    bool done = false;
    while(!done) 
    {
        // Event loop:
        SDL_Event e;
        while(windowManager.pollEvent(e)) {
            if(e.type == SDL_QUIT) {
                done = true; // Leave the loop after this iteration
            }
        }

        /*********************************
         * HERE SHOULD COME THE RENDERING CODE
         *********************************/
	    //clear screen
	    glClear(GL_COLOR_BUFFER_BIT);

	    glBindVertexArray(vao);
	    //glDrawArray(primitives, firstVertex,nbrOfVertex)
	    glDrawArrays(GL_TRIANGLES,0,6);

	    glBindVertexArray(0);


        // Update the display
        windowManager.swapBuffers();
    }


	glDeleteBuffers(1,&vbo);
	glDeleteVertexArrays(1,&vao);

    return EXIT_SUCCESS;
}
