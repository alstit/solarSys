
#include <glimac/Image.hpp> 
#include <glimac/SDLWindowManager.hpp>
#include <glimac/Program.hpp>
#include <glimac/FilePath.hpp>
#include <glimac/glm.hpp>
#include <GL/glew.h>
#include <iostream>


using namespace glimac;
using namespace std;

class Vertex2DUV
{
    public:
    glm::vec2 position;
    glm::vec2 texture;
    Vertex2DUV();
    Vertex2DUV(glm::vec2 position,glm::vec2 texture);
    Vertex2DUV(glm::vec2 position);
};

Vertex2DUV::Vertex2DUV(){};
Vertex2DUV::Vertex2DUV(glm::vec2 position,glm::vec2 texture):position(position),texture(texture){};
Vertex2DUV::Vertex2DUV(glm::vec2 position):position(position)
{
    this->texture = glm::vec2(0,0);
};


glm::mat3 rotate(float a)
{
  return glm::mat3(glm::vec3(cos(glm::radians(a)),sin(glm::radians(a)),0),glm::vec3(-sin(glm::radians(a)),cos(glm::radians(a)),0),glm::vec3(0,0,1.0));
};


glm::mat3 translate(float x,float y)
{
  
  return  glm::mat3(glm::vec3(1.0,0,0),glm::vec3(0,1.0,0),glm::vec3(x,y,1.0));
} ;

glm::mat3 scale(float x,float y)
{
  
  return   glm::mat3(glm::vec3(x,0,0),glm::vec3(0,y,0),glm::vec3(0,0,1.0));
} ;



int main(int argv,char** argc)
{
    SDLWindowManager windowManager(800,600,"GL");

    GLenum glewInitError = glewInit();
    if(GLEW_OK !=glewInitError){
        std::cerr<<glewGetErrorString(glewInitError)<<std::endl;
        return EXIT_FAILURE;
    }

    std::cout << "OpenGL Version : " << glGetString(GL_VERSION) << std::endl;
    std::cout << "GLEW Version : " << glewGetString(GLEW_VERSION) << std::endl;


    //////////////////////load sprite
    std::unique_ptr<Image> sprite = loadImage("/home/als/TP_openGL/GLImac-Template/assets/texture/triforce.png");


    
    FilePath applicationPath(argc[0]);
    Program program = loadProgram(applicationPath.dirPath()+ "shaders/text.vs.glsl",
                                    applicationPath.dirPath() + "shaders/text.fs.glsl");
    program.use();
    
/*
    GLuint spriteId ;
    glGenTextures(1,&spriteId);
    
    glBindTexture(GL_TEXTURE_2D,spriteId);
*/
    GLuint* texture_id= new GLuint;
    glGenTextures(1, texture_id);
    glBindTexture(GL_TEXTURE_2D, *texture_id);


    glTexImage2D( 	GL_TEXTURE_2D,
                    0,
                    GL_RGBA,
                    sprite->getWidth(),
                    sprite->getHeight(),
                    0,
                    GL_RGBA,
                    GL_FLOAT,
                    sprite->getPixels());

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);


    glBindTexture(GL_TEXTURE_2D,0);

    GLint rotation = glGetUniformLocation(program.getGLId(),"uModelMatrix");
    GLint acolor = glGetUniformLocation(program.getGLId(),"uColor");
    GLuint aTexture = glGetUniformLocation(program.getGLId(),"uTexture");

    

    //glm::mat3 m = rotate(45.0);

    


    /////////////////creation du VBO///////////:
    GLuint vbo;
    glGenBuffers(1,&vbo);
    glBindBuffer(GL_ARRAY_BUFFER,vbo);

    Vertex2DUV vertices[] = {Vertex2DUV(glm::vec2(-0.5,-0.5),glm::vec2(0,0)),
                                Vertex2DUV(glm::vec2(0.5,-0.5),glm::vec2(0,1)),
                                Vertex2DUV(glm::vec2(0,0.5),glm::vec2(0.5,1))};


    glBufferData(GL_ARRAY_BUFFER,3*sizeof(Vertex2DUV),vertices,GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER,0);

    ////creation du vao
    GLuint vao;
    glGenVertexArrays(1,&vao);
    glBindVertexArray(vao);

    glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);


    glBindBuffer(GL_ARRAY_BUFFER,vbo);

    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(Vertex2DUV),(void*)offsetof(Vertex2DUV,position));
    glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,sizeof(Vertex2DUV),(void*)offsetof(Vertex2DUV,texture));

    //glBindBuffer(GL_ARRAY_BUFFER,0);
    glBindVertexArray(0);

    

    /////////////////////loop

    bool done = false;
    GLfloat rotValue1 = 0;
    GLfloat rotValue2 = 0;
    while(!done)
    {
        SDL_Event e;
        while(windowManager.pollEvent(e))
        {
            if(e.type == SDL_QUIT)
            {
                done = true;
            }        
        }

        glClear(GL_COLOR_BUFFER_BIT);
        
        glBindTexture(GL_TEXTURE_2D,*texture_id);
        //glUniform1f(time,rotate);
        
        glUniform1i(aTexture,0);
        glUniformMatrix3fv(rotation,1,false,glm::value_ptr(rotate(rotValue1)*scale(0.5,0.5)*translate(0.5,0.5)*rotate(rotValue1)));
        glUniform3f(acolor,1.0,1.0,1.0);
        glBindVertexArray(vao); 
        glDrawArrays(GL_TRIANGLES,0,3);


        glUniformMatrix3fv(rotation,1,false,glm::value_ptr(rotate(rotValue1)*scale(0.5,0.5)*translate(-0.5,0.5)*rotate(rotValue2)));
        glUniform3f(acolor,1.0,0.0,1.0);
        glDrawArrays(GL_TRIANGLES,0,3);

        glUniformMatrix3fv(rotation,1,false,glm::value_ptr(rotate(rotValue1)*scale(0.5,0.5)*translate(-0.5,-0.5)*rotate(rotValue2)));
        glUniform3f(acolor,.0,.0,1.0);
        glDrawArrays(GL_TRIANGLES,0,3);

        glUniformMatrix3fv(rotation,1,false,glm::value_ptr(rotate(rotValue1)*scale(0.5,0.5)*translate(0.5,-0.5)*rotate(rotValue1)));
        glUniform3f(acolor,.0,1.0,1.0);
        glDrawArrays(GL_TRIANGLES,0,3);

        rotValue2-=0.3;
        rotValue1+=0.3;


        glBindVertexArray(0);
        glBindTexture(GL_TEXTURE_2D,0);
        windowManager.swapBuffers();
        
    }

    glDeleteTextures(1,texture_id);
    glDeleteBuffers(1,&vbo);
    glDeleteVertexArrays(1,&vao);

return EXIT_SUCCESS;

}






