

#include <glimac/SDLWindowManager.hpp>
#include <glimac/Program.hpp>
#include <glimac/FilePath.hpp>
#include <glimac/glm.hpp>
#include <GL/glew.h>
#include <iostream>


using namespace glimac;

class Vertex2DUV
{
    public:
    glm::vec2 position;
    glm::vec2 texture;
    Vertex2DUV();
    Vertex2DUV(glm::vec2 position,glm::vec2 texture);
    Vertex2DUV(glm::vec2 position);
};

Vertex2DUV::Vertex2DUV(){};
Vertex2DUV::Vertex2DUV(glm::vec2 position,glm::vec2 texture):position(position),texture(texture){};
Vertex2DUV::Vertex2DUV(glm::vec2 position):position(position)
{
    this->texture = glm::vec2(0,0);
};

int main(int argv,char** argc)
{
    SDLWindowManager windowManager(800,600,"GL");

    GLenum glewInitError = glewInit();
    if(GLEW_OK !=glewInitError){
        std::cerr<<glewGetErrorString(glewInitError)<<std::endl;
        return EXIT_FAILURE;
    }

    std::cout << "OpenGL Version : " << glGetString(GL_VERSION) << std::endl;
    std::cout << "GLEW Version : " << glewGetString(GLEW_VERSION) << std::endl;


    FilePath applicationPath(argc[0]);
	Program program = loadProgram(applicationPath.dirPath() + "shaders/text2D.vs.glsl",
		                      applicationPath.dirPath() + "shaders/text2D.fs.glsl");
	program.use();



    /////////////////creation du VBO///////////:
    GLuint vbo;
    glGenBuffers(1,&vbo);
    glBindBuffer(GL_ARRAY_BUFFER,vbo);

    Vertex2DUV vertices[] = {Vertex2DUV(glm::vec2(-1,-1)),
                                Vertex2DUV(glm::vec2(1,-1)),
                                Vertex2DUV(glm::vec2(-1,1)),
                                Vertex2DUV(glm::vec2(1,1))};


    glBufferData(GL_ARRAY_BUFFER,4*sizeof(Vertex2DUV),vertices,GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER,0);

    // creation du Index Buffer Object
    GLuint ibo;
    glGenBuffers(1,&ibo);
    //binding
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ibo);

    uint32_t indices[6] ;//3*2 triangles 
    indices[0] = 0;indices[1] = 1;indices[2] = 3;indices[3] = 0;indices[4] = 2;indices[5] = 3;
    glBufferData(GL_ELEMENT_ARRAY_BUFFER,6*sizeof(Vertex2DUV),indices,GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);

    ////creation du vao
    GLuint vao;
    glGenVertexArrays(1,&vao);
    glBindVertexArray(vao);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,ibo);
    
    glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER,vbo);

    glVertexAttribPointer(0,2,GL_FLOAT,GL_FALSE,sizeof(Vertex2DUV),(void*)offsetof(Vertex2DUV,position));
    glVertexAttribPointer(1,2,GL_FLOAT,GL_FALSE,sizeof(Vertex2DUV),(void*)offsetof(Vertex2DUV,texture));
    
    glBindVertexArray(0);



    /////////////////////loop

    bool done = false;

    while(!done)
    {
        SDL_Event e;
        while(windowManager.pollEvent(e))
        {
            if(e.type == SDL_QUIT)
            {
                done = true;
            }        
        }

        glClear(GL_COLOR_BUFFER_BIT);
        glBindVertexArray(vao);
        //glDrawArrays(GL_TRIANGLES,0,3);
        glDrawElements(GL_TRIANGLES,6,GL_UNSIGNED_INT,0);

        glBindVertexArray(0);

        windowManager.swapBuffers();
    
    }

    glDeleteBuffers(1,&vbo);
    glDeleteBuffers(1,&vao);

return EXIT_SUCCESS;






};






