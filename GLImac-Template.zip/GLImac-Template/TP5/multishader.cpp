#include <glimac/SDLWindowManager.hpp>
#include <glimac/Image.hpp> 
#include <GL/glew.h>
#include <iostream>
#include <glimac/FilePath.hpp>
#include <glimac/Program.hpp>
#include <glimac/common.hpp>
#include <glimac/Sphere.hpp>
#include <glimac/TrackballCamera.hpp>

using namespace glimac;


struct EarthProgram {
    Program m_Program;

    GLint uMVPMatrix;
    GLint uMVMatrix;
    GLint uNormalMatrix;
    GLint uEarthTexture;
    GLint uCloudTexture;

    EarthProgram(const FilePath& applicationPath):
        m_Program(loadProgram(applicationPath.dirPath() + "shaders/3D.vs.glsl",
                              applicationPath.dirPath() + "shaders/multiText3D.fs.glsl")) {
        uMVPMatrix = glGetUniformLocation(m_Program.getGLId(), "uMVPMatrix");
        uMVMatrix = glGetUniformLocation(m_Program.getGLId(), "uMVMatrix");
        uNormalMatrix = glGetUniformLocation(m_Program.getGLId(), "uNormalMatrix");
        uEarthTexture = glGetUniformLocation(m_Program.getGLId(), "uTexture1");
        uCloudTexture = glGetUniformLocation(m_Program.getGLId(), "uTexture2");
    }
};

struct MoonProgram {
    Program m_Program;

    GLint uMVPMatrix;
    GLint uMVMatrix;
    GLint uNormalMatrix;
    GLint uTexture;

    MoonProgram(const FilePath& applicationPath):
        m_Program(loadProgram(applicationPath.dirPath() + "shaders/3D.vs.glsl",
                              applicationPath.dirPath() + "shaders/text3D.fs.glsl")) {
        uMVPMatrix = glGetUniformLocation(m_Program.getGLId(), "uMVPMatrix");
        uMVMatrix = glGetUniformLocation(m_Program.getGLId(), "uMVMatrix");
        uNormalMatrix = glGetUniformLocation(m_Program.getGLId(), "uNormalMatrix");
        uTexture = glGetUniformLocation(m_Program.getGLId(), "uTexture");
    }
};









int main(int argv,char** argc) {
    // Initialize SDL and open a window
    SDLWindowManager windowManager(800, 600, "GLImac");

    // Initialize glew for OpenGL3+ support
    GLenum glewInitError = glewInit();
    if(GLEW_OK != glewInitError) {
        std::cerr << glewGetErrorString(glewInitError) << std::endl;
        return EXIT_FAILURE;
    }


    std::cout << "OpenGL Version : " << glGetString(GL_VERSION) << std::endl;
    std::cout << "GLEW Version : " << glewGetString(GLEW_VERSION) << std::endl;

    //////load image for texture
    std::unique_ptr<Image> Earthtext = loadImage("/home/als/TP_openGL/GLImac-Template/assets/texture/EarthMap.jpg");
    std::unique_ptr<Image> Cloudtext = loadImage("/home/als/TP_openGL/GLImac-Template/assets/texture/CloudMap.jpg");
    std::unique_ptr<Image> Moontext = loadImage("/home/als/TP_openGL/GLImac-Template/assets/texture/MoonMap.jpg");



    FilePath applicationPath(argc[0]);
    EarthProgram earthProgram(applicationPath);
    MoonProgram moonProgram(applicationPath);

    earthProgram.m_Program.use();
    /*********************************
     * HERE SHOULD COME THE INITIALIZATION CODE
     *********************************/
    /* pour rappel 
    struct ShapeVertex {
        glm::vec3 position;
        glm::vec3 normal;
        glm::vec2 texCoords;
    };*/

    TrackballCamera camera = TrackballCamera();

    Sphere asphere = Sphere(1, 32, 16);

    GLuint vbo;
    glGenBuffers(1,&vbo);
    glBindBuffer(GL_ARRAY_BUFFER,vbo);
    glBufferData(GL_ARRAY_BUFFER,asphere.getVertexCount()*sizeof(Sphere),asphere.getDataPointer(),GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER,0);

    GLuint vao;
    glGenVertexArrays(1,&vao);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER,vbo);

    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);

    glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,sizeof(ShapeVertex),(void*)offsetof(ShapeVertex,position));
    glVertexAttribPointer(1,3,GL_FLOAT,GL_FALSE,sizeof(ShapeVertex),(void*)offsetof(ShapeVertex,normal));
    glVertexAttribPointer(2,2,GL_FLOAT,GL_FALSE,sizeof(ShapeVertex),(void*)offsetof(ShapeVertex,texCoords));
    glBindVertexArray(0);
    /*
    uniform mat4 uMVPMatrix;
    uniform mat4 uMVMatrix;
    uniform mat4 uNormalMatrix;
*/
    
    ////////////////////////////////binding texture
    //glimac::Sphere

    GLuint* texture_id= new GLuint(3);
    glGenTextures(2, texture_id);
    
    //bind earth texture
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, *texture_id);

    glTexImage2D( 	GL_TEXTURE_2D,
                0,
                GL_RGBA,
                Earthtext->getWidth(),
                Earthtext->getHeight(),
                0,
                GL_RGBA,
                GL_FLOAT,
                Earthtext->getPixels());

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
////bind moon texture
    //glBindTexture(GL_TEXTURE_2D,0);
    
    glBindTexture(GL_TEXTURE_2D, *(texture_id+1));

    glTexImage2D( 	GL_TEXTURE_2D,
                0,
                GL_RGBA,
                Moontext->getWidth(),
                Moontext->getHeight(),
                0,
                GL_RGBA,
                GL_FLOAT,
                Moontext->getPixels());

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

//bind Clouds texture
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, *texture_id);
    glBindTexture(GL_TEXTURE_2D, *(texture_id+2));

    glTexImage2D( 	GL_TEXTURE_2D,
                0,
                GL_RGBA,
                Cloudtext->getWidth(),
                Cloudtext->getHeight(),
                0,
                GL_RGBA,
                GL_FLOAT,
                Cloudtext->getPixels());

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D,0);

    glEnable(GL_DEPTH_TEST);
    glm::mat4 ProjMatrix,MVMatrix,NormalMatrix;

    ProjMatrix = glm::perspective(glm::radians(70.f),4.f/3.f,0.1f,100.f);

    MVMatrix = glm::translate(glm::mat4(),glm::vec3(0,0,-5));

    NormalMatrix = glm::transpose(glm::inverse(MVMatrix));

    std::vector<glm::vec3> rotAxis;
    std::vector<glm::vec3> initPosition;
    //for (int i = 0 ; i<32;i++){
        
        rotAxis.push_back(glm::sphericalRand((float)2));
        initPosition.push_back(glm::sphericalRand((float)2));
    //} 

    // Application loop:
    bool done = false;
    while(!done) 
    {
        // Event loop:
        SDL_Event e;
        while(windowManager.pollEvent(e)) 
        {

            if(e.type == SDL_QUIT) 
            {
                done = true; // Leave the loop after this iteration
            }

            if(windowManager.isMouseButtonPressed(SDL_BUTTON_MIDDLE))
            {
                glm::ivec2 mousePos = windowManager.getMousePosition();
                
                camera.moveFront(mousePos[1]);
            }
            if(windowManager.isMouseButtonPressed(SDL_BUTTON_RIGHT))
            {
                glm::ivec2 mousePos = windowManager.getMousePosition();
                camera.rotateLeft(mousePos[1]);
                camera.rotateUp(mousePos[0]);
            }
        }

        /*********************************
         * HERE SHOULD COME THE RENDERING CODE
         *********************************/


         ///////////////////////////////////////////draw planet////////////////
        earthProgram.m_Program.use();
        ////////////////////////////texture
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D,0);
        
        glBindTexture(GL_TEXTURE_2D,*texture_id);
        glUniform1i(earthProgram.uEarthTexture,0);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, *texture_id); // la texture earthTexture est bindée sur l'unité GL_TEXTURE0
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, *(texture_id+2)); // la texture cloudTexture est bindée sur l'unité GL_TEXTURE1
        glUniform1i(earthProgram.uCloudTexture,1);


        //MVMatrix = glm::translate(glm::mat4(),glm::vec3(0,0,-3));
        MVMatrix = camera.getViewMatrix();
        MVMatrix = glm::rotate(MVMatrix, windowManager.getTime(), glm::vec3(0,1,0));
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glUniformMatrix4fv( 	earthProgram.uMVMatrix,
                                    1,
                                    GL_FALSE,
                                    glm::value_ptr(MVMatrix));
        glUniformMatrix4fv( 	earthProgram.uMVPMatrix,
                                    1,
                                    GL_FALSE,
                                    glm::value_ptr(ProjMatrix*MVMatrix));
        glUniformMatrix4fv( 	earthProgram.uNormalMatrix,
                                    1,
                                    GL_FALSE,
                                    glm::value_ptr(NormalMatrix));
        // Update the display
        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES,0,asphere.getVertexCount());
        ////////unbind texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, 0);
        //glBindTexture(GL_TEXTURE_2D,0);





        moonProgram.m_Program.use();

        ////// draw moon//////
        glBindTexture(GL_TEXTURE_2D,*(texture_id+1));
        glUniform1i(moonProgram.uTexture,0);


        //for(int i = 0 ; i< rotAxis.size();i++)
        //{
            
            //MVMatrix = glm::translate(glm::mat4(), glm::vec3(0, 0, -3)); // Translation
            MVMatrix = camera.getViewMatrix();
            MVMatrix = glm::rotate(MVMatrix, windowManager.getTime(), rotAxis[0]); //T*Rlarge
            MVMatrix = glm::translate(MVMatrix, initPosition[0]); // T*Rlarge*Tpos
            MVMatrix = glm::rotate(MVMatrix, windowManager.getTime(), -rotAxis[0]); // T*Rlarge*Tpos*RotationPropre
            MVMatrix = glm::scale(MVMatrix, glm::vec3(0.2, 0.2, 0.2));
        
//MVMatrix = glm::translate(MVMatrix, glm::vec3(0, 0, -3)); // Translation * Rotation * Translation
        
            //MVMatrix = glm::scale(MVMatrix, glm::vec3(0.2, 0.2, 0.2));
            glUniformMatrix4fv( 	moonProgram.uMVPMatrix,
                                        1,
                                        GL_FALSE,
                                        glm::value_ptr(ProjMatrix*MVMatrix));
            glUniformMatrix4fv( 	moonProgram.uNormalMatrix,
                                        1,
                                        GL_FALSE,
                                        glm::value_ptr(NormalMatrix));

            glUniformMatrix4fv( 	moonProgram.uMVMatrix,
                                        1,
                                        GL_FALSE,
                                        glm::value_ptr(MVMatrix));

            glDrawArrays(GL_TRIANGLES,0,asphere.getVertexCount());

        //}
        glBindVertexArray(0);
        glBindTexture(GL_TEXTURE_2D,0);
        windowManager.swapBuffers();
    }

    glDeleteBuffers(1,&vbo);
    glDeleteVertexArrays(1,&vao);
    return EXIT_SUCCESS;
}
